This directory contains the files to build the lp_solve program

To build the program under Windows with the Visual C/C++ compiler, use cvc6.bat (also works for VS.NET)
To build the program under DOS/Windows with the gcc compiler, use cgcc.bat
To build the program under Linux/Unix, use sh ccc
To build the program under Mac OS X 10.3.5, use sh ccc.osx
